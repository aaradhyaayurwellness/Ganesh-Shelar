import React, { useState } from 'react';
import { Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

interface LogoProps {
  className?: string;
  size?: number;
}

export const AaradhyaLogoSymbol: React.FC<LogoProps> = ({ className = "", size = 160 }) => {
  return (
    <motion.svg 
      width={size} 
      height={size} 
      viewBox="0 0 200 200" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={`${className} overflow-visible`}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      whileHover={{ scale: 1.03 }}
    >
      {/* Absolute background breathing glow */}
      <motion.circle 
        cx="100" 
        cy="100" 
        r="75" 
        fill="url(#logoRadialBack)" 
        animate={{ 
          opacity: [0.10, 0.22, 0.10],
          scale: [0.98, 1.05, 0.98]
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      {/* Outer circular gold border */}
      <circle cx="100" cy="100" r="92" stroke="url(#logoGoldGrad)" strokeWidth="3" fill="none" opacity="0.9" />
      
      {/* Outer Dash Ring - Rotates slowly and continuously */}
      <motion.circle 
        cx="100" 
        cy="100" 
        r="84" 
        stroke="url(#logoGoldGrad)" 
        strokeWidth="1.2" 
        strokeDasharray="4 6" 
        fill="none" 
        opacity="0.6"
        animate={{ rotate: 360 }}
        transition={{
          duration: 40,
          repeat: Infinity,
          ease: "linear"
        }}
        style={{ originX: "100px", originY: "100px" }}
      />

      {/* Tree of Life canopy with swaying branch g */}
      <motion.g 
        id="tree-branches"
        animate={{ rotate: [-0.8, 0.8, -0.8] }}
        transition={{
          duration: 4.5,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{ originX: "100px", originY: "135px" }}
      >
        <path d="M100 135 C100 102 74 88 64 74" stroke="url(#logoGoldGrad)" strokeWidth="2.5" strokeLinecap="round" opacity="0.5" />
        <path d="M100 135 C100 102 126 88 136 74" stroke="url(#logoGoldGrad)" strokeWidth="2.5" strokeLinecap="round" opacity="0.5" />
        <path d="M100 135 V52" stroke="url(#logoGoldGrad)" strokeWidth="2.5" strokeLinecap="round" opacity="0.5" />
        
        {/* Upper Leaf Nodes - Animate their scale and sway gently */}
        {/* Center top leaf */}
        <motion.path 
          d="M100 48 Q94 38 100 22 Q106 38 100 48 Z" 
          fill="url(#logoEmerGrad)" 
          stroke="url(#logoGoldGrad)" 
          strokeWidth="1" 
          animate={{ scale: [1, 1.06, 1], rotate: [-1, 1, -1] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          style={{ originX: "100px", originY: "48px" }}
        />
        {/* Left top leaf */}
        <motion.path 
          d="M84 55 Q76 46 81 30 Q91 41 84 55 Z" 
          fill="url(#logoEmerGrad)" 
          stroke="url(#logoGoldGrad)" 
          strokeWidth="1" 
          animate={{ scale: [1, 1.04, 1], rotate: [-2, 2, -2] }}
          transition={{ duration: 3.2, repeat: Infinity, ease: "easeInOut", delay: 0.2 }}
          style={{ originX: "84px", originY: "55px" }}
        />
        {/* Right top leaf */}
        <motion.path 
          d="M116 55 Q124 46 119 30 Q109 41 116 55 Z" 
          fill="url(#logoEmerGrad)" 
          stroke="url(#logoGoldGrad)" 
          strokeWidth="1" 
          animate={{ scale: [1, 1.04, 1], rotate: [-2, 2, -2] }}
          transition={{ duration: 2.8, repeat: Infinity, ease: "easeInOut", delay: 0.4 }}
          style={{ originX: "116px", originY: "55px" }}
        />
        
        {/* Mid-upper Left leaf */}
        <motion.path 
          d="M71 67 Q60 61 63 45 Q75 51 71 67 Z" 
          fill="url(#logoEmerGrad)" 
          stroke="url(#logoGoldGrad)" 
          strokeWidth="1" 
          animate={{ rotate: [-3, 3, -3] }}
          transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut" }}
          style={{ originX: "71px", originY: "67px" }}
        />
        {/* Mid-upper Right leaf */}
        <motion.path 
          d="M129 67 Q140 61 137 45 Q125 51 129 67 Z" 
          fill="url(#logoEmerGrad)" 
          stroke="url(#logoGoldGrad)" 
          strokeWidth="1" 
          animate={{ rotate: [-3, 3, -3] }}
          transition={{ duration: 3.3, repeat: Infinity, ease: "easeInOut", delay: 0.1 }}
          style={{ originX: "129px", originY: "67px" }}
        />

        {/* Mid-lower Left leaf */}
        <motion.path 
          d="M62 84 Q50 83 49 67 Q61 70 62 84 Z" 
          fill="url(#logoEmerGrad)" 
          stroke="url(#logoGoldGrad)" 
          strokeWidth="1" 
          animate={{ rotate: [-4, 2, -4] }}
          transition={{ duration: 3.8, repeat: Infinity, ease: "easeInOut" }}
          style={{ originX: "62px", originY: "84px" }}
        />
        {/* Mid-lower Right leaf */}
        <motion.path 
          d="M138 84 Q150 83 151 67 Q139 70 138 84 Z" 
          fill="url(#logoEmerGrad)" 
          stroke="url(#logoGoldGrad)" 
          strokeWidth="1" 
          animate={{ rotate: [-2, 4, -2] }}
          transition={{ duration: 3.6, repeat: Infinity, ease: "easeInOut", delay: 0.3 }}
          style={{ originX: "138px", originY: "84px" }}
        />

        {/* Bottom Left leaf */}
        <motion.path 
          d="M59 104 Q48 108 43 92 Q55 91 59 104 Z" 
          fill="url(#logoEmerGrad)" 
          stroke="url(#logoGoldGrad)" 
          strokeWidth="1" 
          animate={{ rotate: [-2, 2, -2] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          style={{ originX: "59px", originY: "104px" }}
        />
        {/* Bottom Right leaf */}
        <motion.path 
          d="M141 104 Q152 108 157 92 Q145 91 141 104 Z" 
          fill="url(#logoEmerGrad)" 
          stroke="url(#logoGoldGrad)" 
          strokeWidth="1" 
          animate={{ rotate: [-2, 2, -2] }}
          transition={{ duration: 3.9, repeat: Infinity, ease: "easeInOut", delay: 0.2 }}
          style={{ originX: "141px", originY: "104px" }}
        />
      </motion.g>

      {/* Ayurvedic Pestle & Mortar bowl (Bottom-Left quadrant) - soft bounce on hover */}
      <motion.g 
        id="ayurd-mortar" 
        transform="translate(38, 114) scale(0.20)"
        whileHover={{ y: -4, rotate: -2 }}
        transition={{ type: "spring", stiffness: 300, damping: 10 }}
      >
        {/* Mortar Base */}
        <path d="M20 70 C20 125 120 125 120 70 H20 Z" fill="url(#logoGoldGrad)" stroke="url(#logoDarkGold)" strokeWidth="3" />
        <ellipse cx="70" cy="70" rx="50" ry="14" fill="#022c22" stroke="url(#logoGoldGrad)" strokeWidth="3" />
        {/* Pestle angle handle */}
        <motion.path 
          d="M95 25 L45 85" 
          stroke="url(#logoGoldGrad)" 
          strokeWidth="16" 
          strokeLinecap="round" 
          animate={{ y: [0, 1.5, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        />
        {/* Mortar Stand */}
        <path d="M40 115 H100" stroke="url(#logoGoldGrad)" strokeWidth="8" strokeLinecap="round" />
        {/* Sprouting leaf inside bowl */}
        <path d="M25 50 Q10 40 25 20 Q35 35 25 50 Z" fill="#34d399" />
      </motion.g>

      {/* Splendid Organic Leaves Sprig (Bottom-Right quadrant) */}
      <motion.g 
        id="ayurd-sprig" 
        transform="translate(132, 114) scale(0.22)"
        whileHover={{ y: -4, rotate: 2 }}
        transition={{ type: "spring", stiffness: 300, damping: 10 }}
      >
        <path d="M10 90 Q30 55 65 45" stroke="url(#logoGoldGrad)" strokeWidth="4.5" strokeLinecap="round" fill="none" opacity="0.8" />
        <path d="M35 58 Q18 46 32 24 Q45 40 35 58 Z" fill="#34d399" />
        <path d="M55 46 Q45 28 62 14 Q68 30 55 46 Z" fill="#34d399" stroke="url(#logoGoldGrad)" strokeWidth="1" />
      </motion.g>

      {/* Yogic Lotus posture meditating silhouette in the golden node */}
      <g id="meditating-guru" transform="translate(100, 118)">
        {/* Body outline */}
        <path d="M 0,-38 C -13,-38 -18,-18 -18,-5 C -18,8 -27,10 -32,15 C -35,18 -22,22 0,22 C 22,22 35,18 32,15 C 27,10 18,8 18,-5 C 18,-18 13,-38 0,-38 Z" fill="url(#logoEmerGrad)" />
        {/* Crown head */}
        <circle cx="0" cy="-51" r="9.5" fill="url(#logoEmerGrad)" />
        
        {/* Halo circle ring around crown crown */}
        <motion.ellipse 
          cx="0" 
          cy="-51" 
          r="13" 
          stroke="url(#logoGoldGrad)" 
          strokeWidth="1" 
          strokeDasharray="2 2" 
          opacity="0.5" 
          animate={{ rotate: 360 }}
          transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
        />
        {/* Crossing legs */}
        <path d="M -18,-5 C -27,-5 -35,8 -32,13 C -29,17 -14,19 0,18.5 C 14,19 29,17 32,13 C 35,8 27,-5 18,-5 Z" fill="url(#logoEmerGrad)" />
        <path d="M -32,13 C -38,14 -40,20 -30,22 C -20,24 -8,21 -1,20 M 32,13 C 38,14 40,20 30,22 C 20,24 8,21 1,20" stroke="url(#logoGoldGrad)" strokeWidth="1" strokeLinecap="round" opacity="0.5" />
        
        {/* Heart Chakra Anahata Gold Sparkle - pulses dynamically */}
        <motion.circle 
          cx="0" 
          cy="-21" 
          r="2.5" 
          fill="#fef08a" 
          animate={{ 
            scale: [1, 1.8, 1],
            opacity: [0.7, 1, 0.7],
            fill: ["#fef08a", "#ffffff", "#fef08a"]
          }}
          transition={{
            duration: 1.8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        {/* Heart chakra outward ripple glow */}
        <motion.circle 
          cx="0" 
          cy="-21" 
          r="6" 
          stroke="#fef08a" 
          strokeWidth="0.5"
          fill="none"
          animate={{ 
            scale: [0.8, 2.5],
            opacity: [0.6, 0]
          }}
          transition={{
            duration: 1.8,
            repeat: Infinity,
            ease: "easeOut"
          }}
        />
      </g>

      {/* Definition of gradients */}
      <defs>
        <radialGradient id="logoRadialBack" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#fbbf24" stopOpacity="1" />
          <stop offset="100%" stopColor="#d97706" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="logoGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="50%" stopColor="#fbbf24" />
          <stop offset="100%" stopColor="#ca8a04" />
        </linearGradient>
        <linearGradient id="logoEmerGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#10b981" />
          <stop offset="100%" stopColor="#047857" />
        </linearGradient>
        <linearGradient id="logoDarkGold" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ca8a04" />
          <stop offset="100%" stopColor="#713f12" />
        </linearGradient>
      </defs>
    </motion.svg>
  );
};

interface CompleteLogoProps {
  showText?: boolean;
  className?: string;
  size?: number;
}

export const AaradhyaLogo: React.FC<CompleteLogoProps> = ({ 
  showText = true, 
  className = "", 
  size = 40 
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  return (
    <motion.div 
      className={`flex items-center gap-3.5 ${className} relative select-none`} 
      id="brand-logo-root"
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      whileHover="hover"
    >
      {/* Glow aura behind the image logo on hover */}
      <motion.div 
        className="absolute -inset-1.5 rounded-full bg-gold-400/20 blur-md opacity-0 -z-10"
        variants={{
          hover: { opacity: 0.6, scale: 1.15 }
        }}
        transition={{ duration: 0.4 }}
      />

      <motion.div 
        className="relative rounded-full overflow-hidden flex items-center justify-center p-0.5 border border-gold-300/10 bg-forest-950/40" 
        style={{ width: size, height: size }}
        variants={{
          hover: { scale: 1.08, rotate: [0, -3, 3, 0] }
        }}
        transition={{ duration: 0.4, ease: "easeInOut" }}
      >
        {!imgFailed ? (
          <div className="relative w-full h-full rounded-full overflow-hidden flex items-center justify-center bg-transparent">
            <img
              src="/logo.png"
              alt="Aradhya Ayur Wellness Logo"
              className="h-full w-full object-contain scale-[1.10]"
              referrerPolicy="no-referrer"
              onError={() => {
                setImgFailed(true);
              }}
            />
            {/* Elegant premium sweeping shine metallic flash */}
            <motion.div 
              className="absolute inset-y-0 -left-[100%] w-1/2 bg-gradient-to-r from-transparent via-white/50 to-transparent skew-x-[25deg] pointer-events-none"
              animate={{
                left: ["100%", "-100%"]
              }}
              transition={{
                duration: 2.8,
                repeat: Infinity,
                repeatDelay: 2.5,
                ease: "easeInOut"
              }}
            />
          </div>
        ) : (
          <AaradhyaLogoSymbol size={size} />
        )}

        {/* Absolute overlay indicator with tiny floating sparkles to look luxurious */}
        <div className="absolute inset-0 flex items-center justify-center text-gold-300/10 pointer-events-none">
          <Sparkles className="w-3.5 h-3.5" />
        </div>
      </motion.div>
      
      {showText && (
        <div className="flex flex-col">
          <motion.span 
            className="font-serif text-lg leading-none tracking-[0.08em] text-gold-200 uppercase font-bold"
            variants={{
              hover: { color: "#fef08a", scale: 1.01 }
            }}
            transition={{ duration: 0.2 }}
          >
            Aradhya
          </motion.span>
          <motion.span 
            className="text-[9px] tracking-[0.25em] text-gold-300/85 uppercase leading-none font-extrabold mt-1"
            variants={{
              hover: { tracking: "0.27em" }
            }}
            transition={{ duration: 0.2 }}
          >
            Ayur Wellness
          </motion.span>
        </div>
      )}
    </motion.div>
  );
};

